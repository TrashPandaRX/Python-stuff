# CSP stands for constraint satisfaction problems
# lecture 7 from into to AI
